The documentation of this extension can be found on the 
http://wiki.adventure-php-framework.org/de/ForwardMessage-Erweiterung
wiki page.