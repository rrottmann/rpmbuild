To migrate your APF projects to version 2.0, first migrate to version 1.17 if neccesarry.
Then call the migration php-scripts in this directory from the command line:

$ /path/to/php /path/to/apps-folder/migration/migrate_{SCRIPTNAME}.php

If you are on an linux-system you can use the script migrate.sh.

These scripts do a lot of work for you. However, some work have to be done by you!
See discussion for more information: http://forum.adventure-php-framework.org/viewtopic.php?f=5&t=1407
