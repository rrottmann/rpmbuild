PLEASE NOTE: In order to migrate your APF project to version 2.1 update to version 2.0 before.

MIGRATION can be done as follows using a LINUX-like shell (use cygwin for Windows boxes):

$ cd /path/to/your/project/APF
$ ./migration/migrate.sh /path/to/php

AFTER automatic migration please refer to the manual migration steps described under http://wiki.adventure-php-framework.org/Migration_von_2.0_auf_2.1.
