The documentation of the ArrayPager extension can be 
found on http://wiki.adventure-php-framework.org/ArrayPager-Erweiterung.