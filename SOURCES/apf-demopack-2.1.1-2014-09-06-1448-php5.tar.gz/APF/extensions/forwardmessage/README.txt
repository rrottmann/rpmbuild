The documentation of this extension can be found on the 
http://wiki.adventure-php-framework.org/ForwardMessage-Erweiterung
wiki page.