PLEASE NOTE: In order to migrate your APF project to version 2.0 update to version 1.17 before.

MIGRATION can be done as follows using a LINUX-like shell (use cygwin for Windows boxes):

$ cd /path/to/your/project/APF
$ ./migration/migrate.sh /path/to/php

AFTER automatic migration please refer to the manual migration steps described under http://wiki.adventure-php-framework.org/Migration_von_1.17_auf_2.0.

For QUESTIONS and/or DISCUSSION please refer to http://forum.adventure-php-framework.org/viewtopic.php?f=5&t=1407
