~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~                                     INSTALLATION                                                 ~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In order to run the example application contained in this package a webserver with the PHP module
greater than 5.0.0 must be installed on your local machine. If you don't have expertise in
administration of a webserver, please refer to

   http://www.apachefriends.org/en/xampp-windows.html

and download XAMPP. The present package must them be extracted into the DOCUMENT_ROOT of the
webserver or a VHOST created for the archive. After installing the server and extracting the package
the example application can be viewed by the browser of your choice.


Please note:
~~~~~~~~~~~~

1. In order to guarantee full functionality of the sandbox page on LINUX / UNIX systems, the files
of the sandbox must be assigned the permissions of the user the webserver is operated with.

2. For problems during the installation, please create a thread in the forum under
http://forum.adventure-php-framework.org/en/viewforum.php?f=3.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~