Thank you for using APFelSMS.
Please report all bugs you may encounter to jan.wiese@adventure-php-framework.org

See http://wiki.adventure-php-framework.org/de/APFelSMS for the (german) documentation.
See http://forum.adventure-php-framework.org/de/viewtopic.php?f=11&t=615 for discussion on APFelSMS
