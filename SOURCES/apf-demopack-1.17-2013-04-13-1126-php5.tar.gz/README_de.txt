﻿~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~                                     INSTALLATION                                                 ~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Um die Beispiel-Applikation des Frameworks ausführen zu können muss ein Webserver mit PHP
Version 5.0.0 oder höher installiert sein. Ist noch kein Webserver installiert kann das
bereits vorkonfigurierte Webserver-Paket XAMPP unter

   http://www.apachefriends.org/de/xampp-windows.html

heruntergeladen und entpackt werden. Das mitgelieferte Paket muss daraufhin innerhalb des Document-
Root des Webservers oder innerhalb des Document-Root eines lokalen Webservers entpackt werden.
Anschließend kann die Beispiel-Webseite im Browser aufgerufen werden.


Hinweise:
~~~~~~~~~

1. Um den Betrieb auf LINUX-/UNIX-Systemen sicher zu stellen, sollten die Dateien mit den 
Berechtigungen desjenigen Benutzers ausgestattet werden, mit dem der Webserver betrieben wird.

2. Sollten Probleme bei der Installation auftreten, so verfassen Sie bitte einen Thread im
Forum unter http://forum.adventure-php-framework.org/de/viewforum.php?f=2.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~